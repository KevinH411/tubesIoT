package com.example.tubesIoT;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

//@Component
public class IoTManager {

    @Autowired
    private XBeeReceiver xbeeReceiver;

    @Autowired
    private SensorRepository sensorRepository;

    private final RestTemplate restTemplate = new RestTemplate();
    private final String BLYNK_TOKEN = "MASUKKAN_TOKEN_KAMU_DISINI";

    @Scheduled(fixedDelay = 5000)
    public void runProcess() {
        xbeeReceiver.sendCommand("send");

        try { Thread.sleep(1000); } catch (InterruptedException e) {}

        String rawData = xbeeReceiver.getLatestMessage();
        
        if (rawData != null && rawData.startsWith("SM:")) {
            try {
                String[] parts = rawData.split(";");
                int sm = Integer.parseInt(parts[0].split(":")[1]);
                double t = Double.parseDouble(parts[1].split(":")[1]);
                double ph = Double.parseDouble(parts[2].split(":")[1]);
                double l = Double.parseDouble(parts[3].split(":")[1]);

                SensorData data = new SensorData();
                data.setSoilMoisture(sm);
                data.setTemperature(t);
                data.setPh(ph);
                data.setLux(l);
                sensorRepository.save(data);

                // Kirim ke Blynk
                restTemplate.getForObject("https://sgp1.blynk.cloud/external/api/update?token=" + BLYNK_TOKEN + "&V1=" + sm, String.class);
                restTemplate.getForObject("https://sgp1.blynk.cloud/external/api/update?token=" + BLYNK_TOKEN + "&V2=" + t, String.class);
                restTemplate.getForObject("https://sgp1.blynk.cloud/external/api/update?token=" + BLYNK_TOKEN + "&V3=" + ph, String.class);
                restTemplate.getForObject("https://sgp1.blynk.cloud/external/api/update?token=" + BLYNK_TOKEN + "&V4=" + l, String.class);

                System.out.println("Sukses: Data tersimpan ke Postgres dan Blynk.");
            } catch (Exception e) {
                System.err.println("Error parsing: " + e.getMessage());
            }
        }
    }
}