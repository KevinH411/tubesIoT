package com.example.tubesIoT;

import com.fazecast.jSerialComm.SerialPort;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;
import java.util.Scanner;

//@Component
@Profile("!test")
public class XBeeReceiver {
    @Value("${xbee.port}")
    private String portName;

    @Value("${xbee.baud}")
    private int baudRate;

    private SerialPort port;
    private volatile String latestMessage = null;

    @PostConstruct
    public void init() {
        port = SerialPort.getCommPort(portName);
        port.setBaudRate(baudRate);
        port.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 0, 0);

        if (!port.openPort()) {
            System.err.println("Gagal membuka port XBee!");
            return;
        }

        new Thread(() -> {
            try (Scanner scanner = new Scanner(port.getInputStream())) {
                while (scanner.hasNextLine()) {
                    latestMessage = scanner.nextLine().trim();
                }
            }
        }).start();
    }

    public void sendCommand(String cmd) {
        if (port != null && port.isOpen()) {
            byte[] bytes = (cmd + "\n").getBytes();
            port.writeBytes(bytes, bytes.length);
        }
    }

    public String getLatestMessage() {
        String msg = latestMessage;
        latestMessage = null;
        return msg;
    }
}