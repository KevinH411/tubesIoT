package com.example.tubesIoT;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "sensor_logs")
public class SensorData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private int soilMoisture;
    private double temperature;
    private double ph;
    private double lux;
    private LocalDateTime createdAt = LocalDateTime.now();

    // Getter & Setter
    public void setSoilMoisture(int s) { this.soilMoisture = s; }
    public void setTemperature(double t) { this.temperature = t; }
    public void setPh(double p) { this.ph = p; }
    public void setLux(double l) { this.lux = l; }
}