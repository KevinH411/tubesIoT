@RestController
@RequestMapping("/api/sensors")
@CrossOrigin(origins = "http://localhost:3000") // Izin akses dari React
public class SensorController {

    @Autowired
    private SensorRepository sensorRepository;

    // Ambil data terbaru untuk semua lahan
    @GetMapping("/latest-all")
    public List<SensorData> getAllLatest() {
        // Logika query untuk ambil data terbaru tiap lahanId
        return sensorRepository.findAllLatestForEachLahan(); 
    }

    // Ambil history untuk grafik satu lahan
    @GetMapping("/history/{lahanId}")
    public List<SensorData> getHistory(@PathVariable String lahanId) {
        return sensorRepository.findTop20ByLahanIdOrderByCreatedAtDesc(lahanId);
    }
}