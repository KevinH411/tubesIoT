import React, { useState, useEffect } from 'react'
import axios from 'axios'

function App() {
    const [dataLahan, setDataLahan] = useState([])

    useEffect(() => {
        const fetchData = async () => {
            const result = await axios.get(
                'http://localhost:8080/api/sensors/latest-all'
            )
            setDataLahan(result.data)
        }

        fetchData()
        const interval = setInterval(fetchData, 5000) // Polling tiap 5 detik
        return () => clearInterval(interval)
    }, [])

    return (
        <div className="p-8 bg-gray-100 min-h-screen">
            <h1 className="text-2xl font-bold mb-6">
                Dashboard Pemantauan Multi-Lahan
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {dataLahan.map((lahan) => (
                    <div
                        key={lahan.lahanId}
                        className="bg-white p-6 rounded-lg shadow-md"
                    >
                        <h2 className="text-xl font-semibold border-b pb-2">
                            {lahan.lahanId}
                        </h2>
                        <p className="mt-4">
                            Kelembapan:{' '}
                            <span className="font-bold">
                                {lahan.soilMoisture}%
                            </span>
                        </p>
                        <p>
                            Suhu:{' '}
                            <span className="font-bold">
                                {lahan.temperature}°C
                            </span>
                        </p>
                        <p>
                            pH: <span className="font-bold">{lahan.ph}</span>
                        </p>
                    </div>
                ))}
            </div>
        </div>
    )
}
