package com.example.tubesIoT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TubesIoTApplicationTests {

	@Test
	void contextLoads() {
	}

}
